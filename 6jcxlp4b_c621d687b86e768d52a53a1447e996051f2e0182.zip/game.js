// 游戏主控制器
import { createDeck, shuffleDeck, sortCards, identifyCardType, compareCards, getCardDisplayName, getCardDisplaySuit, CARD_TYPES } from './cards.js';

export class Game {
    constructor() {
        this.players = [
            { id: 0, name: '我', hand: [], isHuman: true, role: null },
            { id: 1, name: '电脑玩家1', hand: [], isHuman: false, role: null },
            { id: 2, name: '电脑玩家2', hand: [], isHuman: false, role: null }
        ];
        
        this.lordCards = [];  // 底牌
        this.currentPlayer = 0;  // 当前玩家
        this.landlord = -1;  // 地主
        this.baseScore = 1;  // 底分
        this.multiplier = 1;  // 倍数
        this.lastPlay = [];  // 上一次出的牌
        this.lastPlayPlayer = -1;  // 上一次出牌的玩家
        this.passCount = 0;  // 连续pass的次数
        this.gameState = 'ready';  // ready, bidding, playing, ended
        this.biddingScores = [0, 0, 0];  // 叫地主的分数
        this.selectedCards = [];  // 玩家选中的牌
    }
    
    // 开始新游戏
    startNewGame() {
        // 重置游戏状态
        this.players.forEach(p => {
            p.hand = [];
            p.role = null;
        });
        this.lordCards = [];
        this.currentPlayer = Math.floor(Math.random() * 3);
        this.landlord = -1;
        this.baseScore = 1;
        this.multiplier = 1;
        this.lastPlay = [];
        this.lastPlayPlayer = -1;
        this.passCount = 0;
        this.biddingScores = [0, 0, 0];
        this.selectedCards = [];
        
        // 创建并洗牌
        const deck = shuffleDeck(createDeck());
        
        // 发牌：每人17张，留3张底牌
        for (let i = 0; i < 51; i++) {
            this.players[i % 3].hand.push(deck[i]);
        }
        
        // 底牌
        this.lordCards = deck.slice(51, 54);
        
        // 排序手牌
        this.players.forEach(p => {
            p.hand = sortCards(p.hand);
        });
        
        this.gameState = 'bidding';
    }
    
    // 叫地主
    bid(playerId, score) {
        if (this.gameState !== 'bidding') return false;
        
        this.biddingScores[playerId] = score;
        
        // 如果有人叫3分，直接成为地主
        if (score === 3) {
            this.setLandlord(playerId);
            return true;
        }
        
        // 检查是否所有人都叫过了
        const allBid = this.biddingScores.every(s => s >= 0);
        if (allBid) {
            const maxScore = Math.max(...this.biddingScores);
            if (maxScore === 0) {
                // 所有人都不叫，重新开始
                return 'restart';
            }
            // 找到叫分最高的玩家
            const landlordId = this.biddingScores.indexOf(maxScore);
            this.setLandlord(landlordId);
            return true;
        }
        
        // 下一个玩家叫地主
        this.currentPlayer = (this.currentPlayer + 1) % 3;
        return false;
    }
    
    // 设置地主
    setLandlord(playerId) {
        this.landlord = playerId;
        this.players[playerId].role = 'landlord';
        this.players[playerId].hand.push(...this.lordCards);
        this.players[playerId].hand = sortCards(this.players[playerId].hand);
        
        // 其他玩家为农民
        this.players.forEach((p, i) => {
            if (i !== playerId) {
                p.role = 'farmer';
            }
        });
        
        this.baseScore = this.biddingScores[playerId];
        this.currentPlayer = playerId;
        this.gameState = 'playing';
    }
    
    // 出牌
    playCards(playerId, cards) {
        if (this.gameState !== 'playing') return false;
        if (playerId !== this.currentPlayer) return false;
        
        // 验证牌型
        const cardType = identifyCardType(cards);
        if (cardType.type === CARD_TYPES.INVALID) {
            return { success: false, message: '无效的牌型' };
        }
        
        // 如果不是首次出牌，需要比较大小
        if (this.lastPlay.length > 0 && this.lastPlayPlayer !== playerId) {
            const comparison = compareCards(cards, this.lastPlay);
            if (comparison <= 0) {
                return { success: false, message: '牌型不符或太小' };
            }
        }
        
        // 从手牌中移除
        const player = this.players[playerId];
        cards.forEach(card => {
            const index = player.hand.findIndex(c => 
                c.suit === card.suit && c.rank === card.rank
            );
            if (index !== -1) {
                player.hand.splice(index, 1);
            }
        });
        
        // 更新游戏状态
        this.lastPlay = cards;
        this.lastPlayPlayer = playerId;
        this.passCount = 0;
        
        // 检查是否获胜
        if (player.hand.length === 0) {
            this.gameState = 'ended';
            return { success: true, gameOver: true, winner: playerId };
        }
        
        // 下一个玩家
        this.currentPlayer = (this.currentPlayer + 1) % 3;
        
        return { success: true };
    }
    
    // 不出（过）
    pass(playerId) {
        if (this.gameState !== 'playing') return false;
        if (playerId !== this.currentPlayer) return false;
        if (this.lastPlayPlayer === playerId) return false;  // 不能对自己的牌pass
        
        this.passCount++;
        
        // 如果连续两个人pass，清空上次出牌
        if (this.passCount >= 2) {
            this.lastPlay = [];
            this.lastPlayPlayer = -1;
            this.passCount = 0;
        }
        
        this.currentPlayer = (this.currentPlayer + 1) % 3;
        return true;
    }
    
    // AI出牌逻辑
    aiPlay(playerId) {
        const player = this.players[playerId];
        
        // 如果是首次出牌或轮到自己出牌
        if (this.lastPlay.length === 0 || this.lastPlayPlayer === playerId) {
            // 出最小的单张
            const sorted = sortCards(player.hand);
            return [sorted[0]];
        }
        
        // 尝试找到能打过的牌
        const lastType = identifyCardType(this.lastPlay);
        
        // 简单AI：尝试找相同牌型且更大的牌
        for (let len = this.lastPlay.length; len <= player.hand.length; len++) {
            for (let i = 0; i <= player.hand.length - len; i++) {
                const cards = player.hand.slice(i, i + len);
                const cardType = identifyCardType(cards);
                
                if (cardType.type !== CARD_TYPES.INVALID) {
                    if (compareCards(cards, this.lastPlay) > 0) {
                        return cards;
                    }
                }
            }
        }
        
        // 找不到能打的牌，随机决定是否出炸弹
        const bombs = this.findBombs(player.hand);
        if (bombs.length > 0 && Math.random() > 0.7) {
            return bombs[0];
        }
        
        return null;  // pass
    }
    
    // 查找手牌中的炸弹
    findBombs(hand) {
        const bombs = [];
        const valueCount = {};
        
        hand.forEach(card => {
            valueCount[card.value] = valueCount[card.value] || [];
            valueCount[card.value].push(card);
        });
        
        // 找四张相同的牌
        Object.values(valueCount).forEach(cards => {
            if (cards.length === 4) {
                bombs.push(cards);
            }
        });
        
        // 检查王炸
        const jokers = hand.filter(c => c.isJoker);
        if (jokers.length === 2) {
            bombs.push(jokers);
        }
        
        return bombs;
    }
    
    // AI叫地主逻辑
    aiBid(playerId) {
        const player = this.players[playerId];
        const hand = player.hand;
        
        // 简单评分系统
        let score = 0;
        
        // 统计大牌
        const bigCards = hand.filter(c => c.value >= 13).length;  // K及以上
        score += bigCards * 2;
        
        // 统计2和王
        const twos = hand.filter(c => c.value === 15).length;
        const jokers = hand.filter(c => c.isJoker).length;
        score += twos * 3 + jokers * 5;
        
        // 统计炸弹
        const bombs = this.findBombs(hand);
        score += bombs.length * 10;
        
        // 根据分数决定叫几分
        const currentMaxBid = Math.max(...this.biddingScores);
        
        if (score >= 30) {
            return 3;
        } else if (score >= 20 && currentMaxBid < 2) {
            return 2;
        } else if (score >= 15 && currentMaxBid < 1) {
            return 1;
        }
        
        return 0;  // 不叫
    }
    
    // 获取游戏状态
    getGameState() {
        return {
            players: this.players.map(p => ({
                id: p.id,
                name: p.name,
                handCount: p.hand.length,
                role: p.role,
                isHuman: p.isHuman
            })),
            currentPlayer: this.currentPlayer,
            landlord: this.landlord,
            baseScore: this.baseScore,
            multiplier: this.multiplier,
            gameState: this.gameState,
            lastPlay: this.lastPlay,
            lastPlayPlayer: this.lastPlayPlayer
        };
    }
}

export default Game;