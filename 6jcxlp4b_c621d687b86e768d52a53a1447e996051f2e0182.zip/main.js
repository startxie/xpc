// 主交互逻辑和UI控制
import { Game } from './game.js';
import { getCardDisplayName, getCardDisplaySuit, identifyCardType, CARD_TYPES } from './cards.js';

class GameUI {
    constructor() {
        this.game = new Game();
        this.selectedCards = [];
        this.initElements();
        this.bindEvents();
    }
    
    // 初始化DOM元素
    initElements() {
        // 玩家手牌区域
        this.playerHandEl = document.getElementById('playerHand');
        this.topPlayerHandEl = document.getElementById('topPlayerHand');
        this.leftPlayerHandEl = document.getElementById('leftPlayerHand');
        
        // 出牌区域
        this.playerPlayEl = document.getElementById('playerPlay');
        this.topPlayerPlayEl = document.getElementById('topPlayerPlay');
        this.leftPlayerPlayEl = document.getElementById('leftPlayerPlay');
        
        // 信息显示
        this.playerCardsEl = document.getElementById('playerCards');
        this.topPlayerCardsEl = document.getElementById('topPlayerCards');
        this.leftPlayerCardsEl = document.getElementById('leftPlayerCards');
        
        this.playerRoleEl = document.getElementById('playerRole');
        this.topPlayerRoleEl = document.getElementById('topPlayerRole');
        this.leftPlayerRoleEl = document.getElementById('leftPlayerRole');
        
        this.gameStatusEl = document.getElementById('gameStatus');
        this.baseScoreEl = document.getElementById('baseScore');
        this.multiplierEl = document.getElementById('multiplier');
        
        // 底牌
        this.lordCardsEl = document.getElementById('lordCards');
        this.lordCardsContainerEl = document.getElementById('lordCardsContainer');
        
        // 按钮
        this.restartBtn = document.getElementById('restartBtn');
        this.biddingButtonsEl = document.getElementById('biddingButtons');
        this.bid1Btn = document.getElementById('bid1Btn');
        this.bid2Btn = document.getElementById('bid2Btn');
        this.bid3Btn = document.getElementById('bid3Btn');
        this.passBidBtn = document.getElementById('passBtn');
        
        this.actionButtonsEl = document.getElementById('actionButtons');
        this.playBtn = document.getElementById('playBtn');
        this.passPlayBtn = document.getElementById('passPlayBtn');
        this.hintBtn = document.getElementById('hintBtn');
        
        // 结果弹窗
        this.resultModal = document.getElementById('resultModal');
        this.resultIcon = document.getElementById('resultIcon');
        this.resultTitle = document.getElementById('resultTitle');
        this.resultMessage = document.getElementById('resultMessage');
        this.closeResultBtn = document.getElementById('closeResultBtn');
    }
    
    // 绑定事件
    bindEvents() {
        this.restartBtn.addEventListener('click', () => this.startGame());
        
        // 叫地主按钮
        this.bid1Btn.addEventListener('click', () => this.handleBid(1));
        this.bid2Btn.addEventListener('click', () => this.handleBid(2));
        this.bid3Btn.addEventListener('click', () => this.handleBid(3));
        this.passBidBtn.addEventListener('click', () => this.handleBid(0));
        
        // 出牌按钮
        this.playBtn.addEventListener('click', () => this.handlePlay());
        this.passPlayBtn.addEventListener('click', () => this.handlePass());
        this.hintBtn.addEventListener('click', () => this.handleHint());
        
        // 关闭结果弹窗
        this.closeResultBtn.addEventListener('click', () => {
            this.resultModal.classList.add('hidden');
            this.startGame();
        });
    }
    
    // 开始游戏
    startGame() {
        this.game.startNewGame();
        this.selectedCards = [];
        this.updateUI();
        this.gameStatusEl.innerHTML = '<div class="text-lg font-semibold">游戏开始！准备叫地主...</div>';
        
        // 延迟开始叫地主流程
        setTimeout(() => {
            this.startBidding();
        }, 1000);
    }
    
    // 开始叫地主
    startBidding() {
        if (this.game.currentPlayer === 0) {
            // 玩家叫地主
            this.showBiddingButtons();
            this.gameStatusEl.innerHTML = '<div class="text-lg font-semibold">请选择是否叫地主</div>';
        } else {
            // AI叫地主
            this.hideBiddingButtons();
            const aiScore = this.game.aiBid(this.game.currentPlayer);
            const playerName = this.game.players[this.game.currentPlayer].name;
            
            if (aiScore > 0) {
                this.gameStatusEl.innerHTML = `<div class="text-lg font-semibold">${playerName} 叫地主 ${aiScore}分</div>`;
            } else {
                this.gameStatusEl.innerHTML = `<div class="text-lg font-semibold">${playerName} 不叫</div>`;
            }
            
            setTimeout(() => {
                const result = this.game.bid(this.game.currentPlayer, aiScore);
                if (result === 'restart') {
                    this.gameStatusEl.innerHTML = '<div class="text-lg font-semibold">所有人都不叫，重新开始...</div>';
                    setTimeout(() => this.startGame(), 2000);
                } else if (result === true) {
                    this.onLandlordSet();
                } else {
                    this.startBidding();
                }
            }, 1500);
        }
    }
    
    // 处理叫地主
    handleBid(score) {
        const result = this.game.bid(0, score);
        this.hideBiddingButtons();
        
        if (score > 0) {
            this.gameStatusEl.innerHTML = `<div class="text-lg font-semibold">你叫地主 ${score}分</div>`;
        } else {
            this.gameStatusEl.innerHTML = '<div class="text-lg font-semibold">你不叫</div>';
        }
        
        setTimeout(() => {
            if (result === 'restart') {
                this.gameStatusEl.innerHTML = '<div class="text-lg font-semibold">所有人都不叫，重新开始...</div>';
                setTimeout(() => this.startGame(), 2000);
            } else if (result === true) {
                this.onLandlordSet();
            } else {
                this.startBidding();
            }
        }, 1000);
    }
    
    // 地主确定后
    onLandlordSet() {
        const landlord = this.game.players[this.game.landlord];
        this.gameStatusEl.innerHTML = `<div class="text-lg font-semibold">${landlord.name} 成为地主！</div>`;
        this.baseScoreEl.textContent = this.game.baseScore;
        
        // 显示底牌
        this.lordCardsEl.classList.remove('hidden');
        this.renderLordCards();
        
        this.updateUI();
        
        setTimeout(() => {
            this.lordCardsEl.classList.add('hidden');
            this.startPlaying();
        }, 3000);
    }
    
    // 开始出牌阶段
    startPlaying() {
        if (this.game.currentPlayer === 0) {
            this.showActionButtons();
            this.gameStatusEl.innerHTML = '<div class="text-lg font-semibold">轮到你出牌</div>';
        } else {
            this.hideActionButtons();
            this.aiTurn();
        }
    }
    
    // AI回合
    aiTurn() {
        const player = this.game.players[this.game.currentPlayer];
        this.gameStatusEl.innerHTML = `<div class="text-lg font-semibold">${player.name} 思考中...</div>`;
        
        setTimeout(() => {
            const cards = this.game.aiPlay(this.game.currentPlayer);
            
            if (cards) {
                const result = this.game.playCards(this.game.currentPlayer, cards);
                if (result.success) {
                    this.renderPlayerPlay(this.game.currentPlayer, cards);
                    this.gameStatusEl.innerHTML = `<div class="text-lg font-semibold">${player.name} 出牌</div>`;
                    
                    if (result.gameOver) {
                        this.onGameOver(result.winner);
                        return;
                    }
                    
                    this.updateUI();
                    setTimeout(() => this.startPlaying(), 1500);
                }
            } else {
                this.game.pass(this.game.currentPlayer);
                this.gameStatusEl.innerHTML = `<div class="text-lg font-semibold">${player.name} 不出</div>`;
                this.updateUI();
                setTimeout(() => this.startPlaying(), 1500);
            }
        }, 1500);
    }
    
    // 处理玩家出牌
    handlePlay() {
        if (this.selectedCards.length === 0) {
            alert('请选择要出的牌');
            return;
        }
        
        const result = this.game.playCards(0, this.selectedCards);
        
        if (!result.success) {
            alert(result.message);
            return;
        }
        
        this.renderPlayerPlay(0, this.selectedCards);
        this.selectedCards = [];
        this.hideActionButtons();
        
        if (result.gameOver) {
            this.onGameOver(result.winner);
            return;
        }
        
        this.updateUI();
        setTimeout(() => this.startPlaying(), 1500);
    }
    
    // 处理玩家不出
    handlePass() {
        if (this.game.lastPlayPlayer === 0) {
            alert('不能对自己的牌不出');
            return;
        }
        
        this.game.pass(0);
        this.selectedCards = [];
        this.hideActionButtons();
        this.gameStatusEl.innerHTML = '<div class="text-lg font-semibold">你选择不出</div>';
        
        this.updateUI();
        setTimeout(() => this.startPlaying(), 1500);
    }
    
    // 提示功能
    handleHint() {
        alert('提示功能开发中...');
    }
    
    // 游戏结束
    onGameOver(winnerId) {
        const winner = this.game.players[winnerId];
        const isPlayerWin = winnerId === 0;
        
        this.resultIcon.textContent = isPlayerWin ? '🎉' : '😢';
        this.resultTitle.textContent = isPlayerWin ? '恭喜获胜！' : '很遗憾失败';
        
        if (winner.role === 'landlord') {
            this.resultMessage.textContent = `地主 ${winner.name} 获胜！`;
        } else {
            this.resultMessage.textContent = `农民获胜！地主输了！`;
        }
        
        this.resultModal.classList.remove('hidden');
    }
    
    // 渲染玩家手牌
    renderPlayerHand() {
        const player = this.game.players[0];
        this.playerHandEl.innerHTML = '';
        
        player.hand.forEach((card, index) => {
            const cardEl = this.createCardElement(card);
            const isSelected = this.selectedCards.some(c => 
                c.suit === card.suit && c.rank === card.rank
            );
            
            if (isSelected) {
                cardEl.classList.add('selected');
            }
            
            cardEl.addEventListener('click', () => {
                if (this.game.gameState !== 'playing' || this.game.currentPlayer !== 0) {
                    return;
                }
                
                if (isSelected) {
                    // 取消选择
                    const idx = this.selectedCards.findIndex(c => 
                        c.suit === card.suit && c.rank === card.rank
                    );
                    this.selectedCards.splice(idx, 1);
                } else {
                    // 选择
                    this.selectedCards.push(card);
                }
                
                this.renderPlayerHand();
            });
            
            this.playerHandEl.appendChild(cardEl);
        });
        
        this.playerCardsEl.textContent = player.hand.length;
    }
    
    // 渲染其他玩家手牌（背面）
    renderOtherPlayerHands() {
        // 上方玩家
        const topPlayer = this.game.players[1];
        this.topPlayerHandEl.innerHTML = '';
        for (let i = 0; i < Math.min(topPlayer.hand.length, 20); i++) {
            const cardBack = document.createElement('div');
            cardBack.className = 'card-back';
            this.topPlayerHandEl.appendChild(cardBack);
        }
        this.topPlayerCardsEl.textContent = topPlayer.hand.length;
        
        // 左侧玩家
        const leftPlayer = this.game.players[2];
        this.leftPlayerHandEl.innerHTML = '';
        for (let i = 0; i < Math.min(leftPlayer.hand.length, 20); i++) {
            const cardBack = document.createElement('div');
            cardBack.className = 'card-back';
            this.leftPlayerHandEl.appendChild(cardBack);
        }
        this.leftPlayerCardsEl.textContent = leftPlayer.hand.length;
    }
    
    // 渲染玩家角色
    renderPlayerRoles() {
        this.game.players.forEach((player, index) => {
            let roleEl;
            if (index === 0) roleEl = this.playerRoleEl;
            else if (index === 1) roleEl = this.topPlayerRoleEl;
            else roleEl = this.leftPlayerRoleEl;
            
            if (player.role) {
                roleEl.classList.remove('hidden');
                const badge = roleEl.querySelector('span');
                if (player.role === 'landlord') {
                    badge.textContent = '地主';
                    badge.className = 'bg-red-500 text-white px-2 py-1 rounded text-xs font-bold';
                } else {
                    badge.textContent = '农民';
                    badge.className = 'bg-green-500 text-white px-2 py-1 rounded text-xs font-bold';
                }
            } else {
                roleEl.classList.add('hidden');
            }
        });
    }
    
    // 渲染出牌区
    renderPlayerPlay(playerId, cards) {
        let playEl;
        if (playerId === 0) playEl = this.playerPlayEl;
        else if (playerId === 1) playEl = this.topPlayerPlayEl;
        else playEl = this.leftPlayerPlayEl;
        
        playEl.innerHTML = '';
        
        cards.forEach(card => {
            const cardEl = this.createCardElement(card);
            cardEl.classList.add('small', 'playing');
            playEl.appendChild(cardEl);
        });
        
        // 清除其他玩家的出牌区
        if (playerId === 0) {
            this.topPlayerPlayEl.innerHTML = '';
            this.leftPlayerPlayEl.innerHTML = '';
        } else if (playerId === 1) {
            this.playerPlayEl.innerHTML = '';
            this.leftPlayerPlayEl.innerHTML = '';
        } else {
            this.playerPlayEl.innerHTML = '';
            this.topPlayerPlayEl.innerHTML = '';
        }
    }
    
    // 渲染底牌
    renderLordCards() {
        this.lordCardsContainerEl.innerHTML = '';
        this.game.lordCards.forEach(card => {
            const cardEl = this.createCardElement(card);
            cardEl.classList.add('dealing');
            this.lordCardsContainerEl.appendChild(cardEl);
        });
    }
    
    // 创建卡牌元素
    createCardElement(card) {
        const cardEl = document.createElement('div');
        cardEl.className = 'card';
        
        if (card.isJoker) {
            cardEl.classList.add('joker');
            if (card.isBig) {
                cardEl.classList.add('big');
            }
        } else if (card.isRed) {
            cardEl.classList.add('red');
        } else {
            cardEl.classList.add('black');
        }
        
        const rankEl = document.createElement('div');
        rankEl.className = 'card-rank';
        rankEl.textContent = getCardDisplayName(card);
        
        const suitEl = document.createElement('div');
        suitEl.className = 'card-suit';
        suitEl.textContent = getCardDisplaySuit(card);
        
        cardEl.appendChild(rankEl);
        cardEl.appendChild(suitEl);
        
        return cardEl;
    }
    
    // 显示/隐藏按钮
    showBiddingButtons() {
        this.biddingButtonsEl.classList.remove('hidden');
    }
    
    hideBiddingButtons() {
        this.biddingButtonsEl.classList.add('hidden');
    }
    
    showActionButtons() {
        this.actionButtonsEl.classList.remove('hidden');
    }
    
    hideActionButtons() {
        this.actionButtonsEl.classList.add('hidden');
    }
    
    // 更新UI
    updateUI() {
        this.renderPlayerHand();
        this.renderOtherPlayerHands();
        this.renderPlayerRoles();
    }
}

// 初始化游戏
const gameUI = new GameUI();
gameUI.startGame();