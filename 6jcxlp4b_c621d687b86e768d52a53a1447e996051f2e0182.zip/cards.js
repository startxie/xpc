// 卡牌数据和基础逻辑模块

// 花色定义
export const SUITS = {
    SPADE: '♠',    // 黑桃
    HEART: '♥',    // 红桃
    CLUB: '♣',     // 梅花
    DIAMOND: '♦'   // 方块
};

// 牌面值定义
export const RANKS = {
    '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10,
    'J': 11, 'Q': 12, 'K': 13, 'A': 14, '2': 15, 'JOKER': 16, 'JOKER_BIG': 17
};

// 创建一副完整的扑克牌
export function createDeck() {
    const deck = [];
    const suits = [SUITS.SPADE, SUITS.HEART, SUITS.CLUB, SUITS.DIAMOND];
    const ranks = ['3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A', '2'];
    
    // 创建52张普通牌
    for (const suit of suits) {
        for (const rank of ranks) {
            deck.push({
                suit: suit,
                rank: rank,
                value: RANKS[rank],
                isRed: suit === SUITS.HEART || suit === SUITS.DIAMOND
            });
        }
    }
    
    // 添加两张王牌
    deck.push({
        suit: '🃏',
        rank: 'JOKER',
        value: RANKS.JOKER,
        isJoker: true,
        isBig: false
    });
    
    deck.push({
        suit: '🃏',
        rank: 'JOKER_BIG',
        value: RANKS.JOKER_BIG,
        isJoker: true,
        isBig: true
    });
    
    return deck;
}

// 洗牌
export function shuffleDeck(deck) {
    const shuffled = [...deck];
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

// 对手牌进行排序
export function sortCards(cards) {
    return [...cards].sort((a, b) => {
        if (a.value !== b.value) {
            return a.value - b.value;
        }
        // 相同点数按花色排序
        const suitOrder = [SUITS.DIAMOND, SUITS.CLUB, SUITS.HEART, SUITS.SPADE];
        return suitOrder.indexOf(a.suit) - suitOrder.indexOf(b.suit);
    });
}

// 牌型识别
export const CARD_TYPES = {
    INVALID: 'invalid',           // 无效牌型
    SINGLE: 'single',             // 单张
    PAIR: 'pair',                 // 对子
    TRIPLE: 'triple',             // 三张
    TRIPLE_WITH_SINGLE: 'triple_single',  // 三带一
    TRIPLE_WITH_PAIR: 'triple_pair',      // 三带二
    STRAIGHT: 'straight',         // 顺子（至少5张）
    PAIR_STRAIGHT: 'pair_straight',       // 连对（至少3对）
    TRIPLE_STRAIGHT: 'triple_straight',   // 飞机（至少2个三张）
    FOUR_WITH_TWO: 'four_two',    // 四带二
    BOMB: 'bomb',                 // 炸弹
    ROCKET: 'rocket'              // 王炸
};

// 识别牌型
export function identifyCardType(cards) {
    if (!cards || cards.length === 0) {
        return { type: CARD_TYPES.INVALID };
    }
    
    const sorted = sortCards(cards);
    const count = cards.length;
    
    // 统计每个点数的数量
    const valueCount = {};
    sorted.forEach(card => {
        valueCount[card.value] = (valueCount[card.value] || 0) + 1;
    });
    
    const values = Object.keys(valueCount).map(Number).sort((a, b) => a - b);
    const counts = Object.values(valueCount).sort((a, b) => b - a);
    
    // 王炸
    if (count === 2 && sorted[0].value === RANKS.JOKER && sorted[1].value === RANKS.JOKER_BIG) {
        return { type: CARD_TYPES.ROCKET, value: sorted[0].value };
    }
    
    // 炸弹
    if (count === 4 && counts[0] === 4) {
        return { type: CARD_TYPES.BOMB, value: values[0], length: 4 };
    }
    
    // 单张
    if (count === 1) {
        return { type: CARD_TYPES.SINGLE, value: sorted[0].value };
    }
    
    // 对子
    if (count === 2 && counts[0] === 2) {
        return { type: CARD_TYPES.PAIR, value: values[0] };
    }
    
    // 三张
    if (count === 3 && counts[0] === 3) {
        return { type: CARD_TYPES.TRIPLE, value: values[0] };
    }
    
    // 三带一
    if (count === 4 && counts[0] === 3 && counts[1] === 1) {
        const tripleValue = values.find(v => valueCount[v] === 3);
        return { type: CARD_TYPES.TRIPLE_WITH_SINGLE, value: tripleValue };
    }
    
    // 三带二
    if (count === 5 && counts[0] === 3 && counts[1] === 2) {
        const tripleValue = values.find(v => valueCount[v] === 3);
        return { type: CARD_TYPES.TRIPLE_WITH_PAIR, value: tripleValue };
    }
    
    // 顺子（至少5张，不能包含2和王）
    if (count >= 5 && counts[0] === 1 && isConsecutive(values) && values[values.length - 1] < RANKS['2']) {
        return { type: CARD_TYPES.STRAIGHT, value: values[0], length: count };
    }
    
    // 连对（至少3对）
    if (count >= 6 && count % 2 === 0 && counts[0] === 2 && isConsecutive(values) && values[values.length - 1] < RANKS['2']) {
        return { type: CARD_TYPES.PAIR_STRAIGHT, value: values[0], length: count / 2 };
    }
    
    // 飞机（至少2个三张）
    if (count >= 6 && count % 3 === 0) {
        const tripleValues = values.filter(v => valueCount[v] === 3);
        if (tripleValues.length >= 2 && isConsecutive(tripleValues) && tripleValues[tripleValues.length - 1] < RANKS['2']) {
            return { type: CARD_TYPES.TRIPLE_STRAIGHT, value: tripleValues[0], length: tripleValues.length };
        }
    }
    
    // 四带二
    if (count === 6 && counts[0] === 4) {
        const fourValue = values.find(v => valueCount[v] === 4);
        return { type: CARD_TYPES.FOUR_WITH_TWO, value: fourValue };
    }
    
    return { type: CARD_TYPES.INVALID };
}

// 检查是否连续
function isConsecutive(values) {
    for (let i = 1; i < values.length; i++) {
        if (values[i] - values[i - 1] !== 1) {
            return false;
        }
    }
    return true;
}

// 比较两组牌的大小
export function compareCards(cards1, cards2) {
    const type1 = identifyCardType(cards1);
    const type2 = identifyCardType(cards2);
    
    // 王炸最大
    if (type1.type === CARD_TYPES.ROCKET) return 1;
    if (type2.type === CARD_TYPES.ROCKET) return -1;
    
    // 炸弹大于其他牌型
    if (type1.type === CARD_TYPES.BOMB && type2.type !== CARD_TYPES.BOMB) return 1;
    if (type2.type === CARD_TYPES.BOMB && type1.type !== CARD_TYPES.BOMB) return -1;
    
    // 炸弹之间比较
    if (type1.type === CARD_TYPES.BOMB && type2.type === CARD_TYPES.BOMB) {
        return type1.value - type2.value;
    }
    
    // 牌型不同无法比较
    if (type1.type !== type2.type) return 0;
    
    // 长度不同无法比较（顺子、连对等）
    if (type1.length && type2.length && type1.length !== type2.length) return 0;
    
    // 比较点数
    return type1.value - type2.value;
}

// 获取可以打出的牌型提示
export function getPlayableHints(hand, lastPlay) {
    const hints = [];
    
    if (!lastPlay || lastPlay.length === 0) {
        // 首次出牌，找最小的单张
        const sorted = sortCards(hand);
        hints.push([sorted[0]]);
        return hints;
    }
    
    const lastType = identifyCardType(lastPlay);
    
    // 遍历所有可能的组合
    for (let i = 0; i < hand.length; i++) {
        for (let j = i + 1; j <= hand.length; j++) {
            const combo = hand.slice(i, j);
            const comboType = identifyCardType(combo);
            
            if (comboType.type !== CARD_TYPES.INVALID) {
                if (compareCards(combo, lastPlay) > 0) {
                    hints.push(combo);
                }
            }
        }
    }
    
    return hints;
}

// 生成卡牌的显示名称
export function getCardDisplayName(card) {
    if (card.isJoker) {
        return card.isBig ? '大王' : '小王';
    }
    return card.rank;
}

// 生成卡牌的显示花色
export function getCardDisplaySuit(card) {
    if (card.isJoker) {
        return card.suit;
    }
    return card.suit;
}

export default {
    SUITS,
    RANKS,
    CARD_TYPES,
    createDeck,
    shuffleDeck,
    sortCards,
    identifyCardType,
    compareCards,
    getPlayableHints,
    getCardDisplayName,
    getCardDisplaySuit
};